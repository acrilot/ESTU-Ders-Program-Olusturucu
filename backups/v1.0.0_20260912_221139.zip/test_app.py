import unittest
import json
from app import app

class TestWebApp(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_index_route(self):
        res = self.client.get("/")
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"EST", res.data)

    def test_catalog_route(self):
        res = self.client.get("/api/catalog")
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("departments", data)
        self.assertGreater(len(data["departments"]), 0)

    def test_solve_api_endpoint(self):
        # Fetch catalog first
        cat_res = self.client.get("/api/catalog")
        catalog = cat_res.get_json()
        hee = next(d for d in catalog["departments"] if d["code"] == "HEE")
        sem7 = next(s for s in hee["semesters"] if "7. Yarıyıl" in s["label"])
        selected = [c for c in sem7["courses"] if c["code"] in ["HEE4007", "HEE4009", "HEE421", "HEE423"]]

        payload = {
            "courses": selected,
            "criteria": {
                "allowed_days": ["Pzt", "Sal", "Crs", "Prs", "Cum"],
                "require_lunch": True,
                "lunch_min_hours": 0.5,
                "earliest_start": 8.0,
                "latest_end": 20.0,
                "allow_star1": False
            }
        }
        res = self.client.post("/api/solve", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("schedules", data)
        self.assertGreater(len(data["schedules"]), 0)
        print(f"\n[Test API] Successfully generated {len(data['schedules'])} schedules via /api/solve")

if __name__ == "__main__":
    unittest.main()

