import os
import json
from flask import Flask, send_from_directory, jsonify, request
from pdf_parser import parse_pdf, build_catalog
from scheduler import solve_schedules

app = Flask(__name__, static_folder="static")

PDF_FILENAME = "2026-2027 Güz Ders Programı.pdf"
CATALOG_PATH = os.path.join("static", "courses_data.json")

def ensure_catalog_exists():
    if not os.path.exists(CATALOG_PATH):
        print("[Sunucu] courses_data.json bulunamadı, PDF ayrıştırılıyor...")
        if os.path.exists(PDF_FILENAME):
            courses = parse_pdf(PDF_FILENAME)
            catalog = build_catalog(courses)
            with open(CATALOG_PATH, "w", encoding="utf-8") as f:
                json.dump(catalog, f, ensure_ascii=False, indent=2)
            print(f"[Sunucu] {len(courses)} ders ayrıştırıldı ve kaydedildi.")
        else:
            print(f"[Uyarı] {PDF_FILENAME} bulunamadı.")

@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")

@app.route("/<path:path>")
def serve_static(path):
    return send_from_directory(app.static_folder, path)

@app.route("/api/catalog", methods=["GET"])
def get_catalog():
    if os.path.exists(CATALOG_PATH):
        with open(CATALOG_PATH, "r", encoding="utf-8") as f:
            return jsonify(json.load(f))
    return jsonify({"error": "Catalog not found"}), 404

@app.route("/api/solve", methods=["POST"])
def solve():
    data = request.get_json() or {}
    courses = data.get("courses", [])
    criteria = data.get("criteria", {})
    max_results = data.get("max_results", 50)
    
    results = solve_schedules(courses, criteria, max_results)
    return jsonify({"schedules": results, "count": len(results)})

if __name__ == "__main__":
    ensure_catalog_exists()
    port = int(os.environ.get("PORT", 5000))
    print(f"==================================================")
    print(f" ESTÜ Ders Programı Hazırlama Otomasyonu")
    print(f" Sunucu başlatıldı: http://127.0.0.1:{port}")
    print(f"==================================================")
    app.run(host="127.0.0.1", port=port, debug=False)
